﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.SqlServer.Server;
using MySql.Data.MySqlClient;

namespace Class_Assignment___Take_Home_W14
{
    public partial class Form1 : Form
    {
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        string sqlQuery;
        DataTable team = new DataTable();
        DataTable team2 = new DataTable();
        DataTable dataTable = new DataTable();
        DataTable match = new DataTable();
        DataTable insert = new DataTable();
        DataTable cek = new DataTable();
        DataTable tim = new DataTable();
        DataTable player = new DataTable();
        DataTable addMatch = new DataTable();   
        DataTable display = new DataTable();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Semua ComboBox terkoneksi, jadi semua ComboBox harus di klik dulu biar muncul isinya yaaa");
            sqlConnect = new MySqlConnection("server=localhost;uid=root;pwd=Uc234616516;database=premier_league;");
            cbType.Items.Add("GO");
            cbType.Items.Add("GP");
            cbType.Items.Add("GW");
            cbType.Items.Add("CR");
            cbType.Items.Add("PM");

            cek.Columns.Add("Match_ID");
            cek.Columns.Add("Minute");
            cek.Columns.Add("Team_ID");
            cek.Columns.Add("Player_id");
            cek.Columns.Add("Type");
            cek.Columns.Add("Delete");

            sqlQuery = "SELECT match_date FROM `match`";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(match);
            dtpLastMatch.Text = match.Rows[match.Rows.Count - 1][0].ToString();

            addMatch.Columns.Add("Minute");
            addMatch.Columns.Add("Team");
            addMatch.Columns.Add("Player");
            addMatch.Columns.Add("Type");
            addMatch.Columns.Add("Team_ID");
            addMatch.Columns.Add("Player_ID");

            display.Columns.Add("Minute");
            display.Columns.Add("Team");
            display.Columns.Add("Player");
            display.Columns.Add("Type");

            player.Columns.Add("player_name");
            player.Columns.Add("player_id");

            tim.Columns.Add("team_name");
            tim.Columns.Add("team_id");            
        }

        private void dtp1_ValueChanged(object sender, EventArgs e)
        {
            if (dtp1.Value.Year == dtpLastMatch.Value.Year)
            {
                if (dtp1.Value.Month == dtpLastMatch.Value.Month)
                {
                    if (dtp1.Value.Day < dtpLastMatch.Value.Day)
                    {
                        MessageBox.Show("TANGGAL HARUS LEBIH BESAR DARI TANGGAL TERAKHIR PERTANDINGAN DI DATABASE");
                    }
                }
                else if (dtp1.Value.Month < dtpLastMatch.Value.Month)
                {
                    MessageBox.Show("TANGGAL HARUS LEBIH BESAR DARI TANGGAL TERAKHIR PERTANDINGAN DI DATABASE");
                }
            }
            else if (dtp1.Value.Year < dtpLastMatch.Value.Year)
            {
                MessageBox.Show("TAHUN HARUS LEBIH BESAR DARI TANGGAL TERAKHIR PERTANDINGAN DI DATABASE");
            }


            if (cbTeamHome.SelectedIndex != 0 && cbTeamAway.SelectedIndex != 0)
            {
                //MessageBox.Show(dtp1.Value.ToString());
                dataTable = new DataTable();
                int year = dtp1.Value.Year;
                string id = year.ToString();
                sqlQuery = "SELECT COUNT(match_id) FROM `match`" +
                    $"WHERE YEAR(match_date) = {year}";
                sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dataTable);
                if (dataTable.Rows[0][0].ToString().Length == 3)
                {
                    id = year.ToString() + (Convert.ToInt16(dataTable.Rows[0][0]) + 1).ToString();
                }
                if (dataTable.Rows[0][0].ToString().Length == 2)
                {
                    id = year.ToString() + "0" + (Convert.ToInt16(dataTable.Rows[0][0]) + 1).ToString();
                }
                if (dataTable.Rows[0][0].ToString().Length == 1)
                {
                    id = year.ToString() + "00" + (Convert.ToInt16(dataTable.Rows[0][0]) + 1).ToString();
                }
                tbMatchID.Text = id;
                sqlQuery = "SELECT team_name,team_id from team;";
                sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                dataTable = new DataTable();
                sqlDataAdapter.Fill(team);
                sqlDataAdapter.Fill(team2);

            }
        }

        private void cbTeamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            tim.Rows.Clear();
            tim.Rows.Add(cbTeamHome.Text, cbTeamHome.SelectedValue);
            tim.Rows.Add(cbTeamAway.Text, cbTeamAway.SelectedValue);
            cbTeam.DataSource = tim;
            cbTeam.DisplayMember = "team_name";
            cbTeam.ValueMember = "team_id";
        }

        private void cbTeamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            tim.Rows.Clear();
            tim.Rows.Add(cbTeamHome.Text, cbTeamHome.SelectedValue);
            tim.Rows.Add(cbTeamAway.Text, cbTeamAway.SelectedValue);
            cbTeam.DataSource = tim;
            cbTeam.DisplayMember = "team_name";
            cbTeam.ValueMember = "team_id";
        }

        private void cbTeamHome_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (cbTeamAway.SelectedItem != null && cbTeamHome.SelectedItem != null)
            {

                if (cbTeamHome.SelectedIndex == cbTeamAway.SelectedIndex)
                {
                    MessageBox.Show("ERRORRRRRRRR; YANG DIPILIH GABOLEH SAMAAA");
                }

            }
        }

        private void cbTeamAway_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (cbTeamAway.SelectedItem != null && cbTeamHome.SelectedItem != null)
            {

                if (cbTeamHome.SelectedIndex == cbTeamAway.SelectedIndex)
                {
                    MessageBox.Show("ERRORRRRRRRR; YANG DIPILIH GABOLEH SAMAAA");
                }
            }
        }

        private void cbTeamHome_MouseClick(object sender, MouseEventArgs e)
        {
            cbTeamHome.DataSource = team;
            cbTeamHome.DisplayMember = "team_name";
            cbTeamHome.ValueMember = "team_id";
        }

        private void cbTeamAway_MouseClick(object sender, MouseEventArgs e)
        {
            cbTeamAway.DataSource = team2;
            cbTeamAway.DisplayMember = "team_name";
            cbTeamAway.ValueMember = "team_id";
        }

        private void cbTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            sqlQuery = $"SELECT p.player_name, p.player_id, t.team_name from player p, team t WHERE p.team_id = t.team_id AND t.team_name = '{cbTeam.Text}';";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            dataTable = new DataTable();
            sqlDataAdapter.Fill(dataTable);
            cbPlayer.DataSource = dataTable;
            cbPlayer.DisplayMember = "player_name";
            cbPlayer.ValueMember = "player_id";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            player.Rows.Add(cbPlayer.Text, cbPlayer.SelectedValue);
            addMatch.Rows.Add(tbMinute.Text, cbTeam.Text, cbPlayer.Text, cbType.Text, cbTeam.SelectedValue, cbPlayer.SelectedValue);
            display.Rows.Add(tbMinute.Text, cbTeam.Text, cbPlayer.Text, cbType.Text);
            dataGridView1.DataSource = display;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.CurrentRow.Index;
            dataGridView1.Rows.RemoveAt(index);
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {            
            int goalHome = 0;
            int goalAway = 0;
            
            for (int i = 0; i < addMatch.Rows.Count; i++)
            {
                cek.Rows.Add(tbMatchID.Text, addMatch.Rows[i][0], addMatch.Rows[i][4], addMatch.Rows[i][5], addMatch.Rows[i][3]);
            }

            for (int i = 0; i < cek.Rows.Count; i++)
            {
                sqlQuery = $"INSERT INTO dmatch VALUES ('{cek.Rows[i][0].ToString()}','{cek.Rows[i][1].ToString()}','{cek.Rows[i][2].ToString()}','{cek.Rows[i][3].ToString()}','{cek.Rows[i][4].ToString()}','0')";
                sqlConnect.Open();
                sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                sqlCommand.ExecuteNonQuery();
                sqlConnect.Close();
            }

            for (int i = 0;i < addMatch.Rows.Count;i++)
            {
                if (addMatch.Rows[i][3].ToString() == "GO" || addMatch.Rows[i][3].ToString() == "GP")
                {
                    if(addMatch.Rows[i][4].ToString() == cbTeamHome.SelectedValue.ToString())
                    {
                        goalHome++;
                    }
                    else if(addMatch.Rows[i][4].ToString() == cbTeamAway.SelectedValue.ToString())
                    {
                        goalAway++;
                    }                    
                }                
                else if(addMatch.Rows[i][3].ToString() == "GW")
                {
                    if(addMatch.Rows[i][4].ToString() == cbTeamAway.SelectedValue.ToString())
                    {
                        goalHome++;
                    }
                    else if(addMatch.Rows[i][4].ToString() == cbTeamHome.SelectedValue.ToString())
                    {
                        goalAway++;
                    }
                }                
            }

            string tgl = "";
            if(dtp1.Value.Month < 10 && dtp1.Value.Day > 9)
            {
                tgl = (dtp1.Value.Year + "-0" + dtp1.Value.Month + "-" + dtp1.Value.Day).ToString();
            }
            else if(dtp1.Value.Day < 10 && dtp1.Value.Month > 9)
            {
                tgl = (dtp1.Value.Year + "-" + dtp1.Value.Month + "-0" + dtp1.Value.Day).ToString();
            }
            else if(dtp1.Value.Month < 10 && dtp1.Value.Year < 10)
            {
                tgl = (dtp1.Value.Year + "-0" + dtp1.Value.Month + "-0" + dtp1.Value.Day).ToString();
            }
            //MessageBox.Show($"'{tbMatchID.Text}', '{tgl}', '{cbTeamHome.SelectedValue.ToString()}', '{cbTeamAway.SelectedValue.ToString()}', '{goalHome}', '{goalAway}', 'M002', '0'");

            sqlQuery = $"INSERT INTO `match` VALUES ('{tbMatchID.Text}','{dtp1.Value.Year + "-" + dtp1.Value.Month + "-" + dtp1.Value.Day}','{cbTeamHome.SelectedValue.ToString()}','{cbTeamAway.SelectedValue.ToString()}','{goalHome}','{goalAway}', 'M002', '0')";
            sqlConnect.Open();
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlCommand.ExecuteNonQuery();
            sqlConnect.Close();            
            dgvCek.DataSource = cek;
        }
    }
}
